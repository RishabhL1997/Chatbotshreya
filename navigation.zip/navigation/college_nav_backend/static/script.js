// Fetch locations and populate dropdown
fetch("/locations")
  .then(response => response.json())
  .then(data => {
    const dropdown = document.getElementById("location-dropdown");
    dropdown.innerHTML = "<option value=''>-- Or select from list --</option>"; // reset

    data.forEach(loc => {
      const option = document.createElement("option");
      option.value = loc.latitude + "," + loc.longitude; // store coordinates
      option.textContent = loc.location;                  // show name
      dropdown.appendChild(option);
    });
  })
  .catch(err => console.error("Failed to load locations:", err));

// Navigate function (used by both dropdown change and button)
function navigate() {
  const destination = document.getElementById("location-dropdown").value;

  if (!destination) {
    alert("Please select a location!");
    return;
  }

  const origin = prompt("Enter your current location name:");

  fetch("/locations")
    .then(res => res.json())
    .then(data => {
      const start = data.find(loc =>
        loc.location.toLowerCase() === origin.toLowerCase()
      );

      if (!start) {
        alert("Starting location not found!");
        return;
      }

      window.open(
        `https://www.google.com/maps/dir/?api=1&origin=${start.latitude},${start.longitude}&destination=${destination}&travelmode=walking`,
        "_blank"
      );
    });
}

// Add event listener for dropdown change
//document.getElementById("location-dropdown").addEventListener("change", function () {
  //if (this.value !== "") {
    //navigate();
  //}
//});

// Feedback toggle
function toggleFeedback() {
  const box = document.getElementById("feedback-box");
  box.style.display = (box.style.display === "block") ? "none" : "block";
}

// Feedback submit
function submitFeedback() {
  const feedback = document.getElementById("feedback-text").value.trim();
  const status = document.getElementById("feedback-status");

  if (!feedback) {
    status.textContent = "⚠️ Please enter your message.";
    status.style.color = "red";
    return;
  }

  status.textContent = "✅ Thanks for your feedback!";
  status.style.color = "green";
  document.getElementById("feedback-text").value = "";
}

// Help toggle
function showHelp() {
  const help = document.getElementById("help-info");
  help.style.display = (help.style.display === "block") ? "none" : "block";
}

// Chatbot toggle
/// Chatbot Toggle



document.addEventListener("DOMContentLoaded", function () {

  // Dropdown change event
  const dropdown = document.getElementById("location-dropdown");
  if (dropdown) {
    dropdown.addEventListener("change", function () {
      if (this.value !== "") {
        navigate();
      }
    });
  }

  // Chatbot code starts here
  const chatBtn = document.getElementById("chat-button");
  const chatbot = document.getElementById("chatbot");
  const closeBtn = document.getElementById("chatbot-close");
  const sendBtn = document.getElementById("send-btn");
  const input = document.getElementById("chat-input");
  const chatWindow = document.getElementById("chat-window");

  if (!chatBtn || !chatbot || !closeBtn || !sendBtn || !input || !chatWindow) {
    console.error("Chatbot elements missing!");
    return;
  }

  chatBtn.addEventListener("click", () => {
    chatbot.style.display = "flex";
  });

  closeBtn.addEventListener("click", () => {
    chatbot.style.display = "none";
  });

  sendBtn.addEventListener("click", sendMessage);

  input.addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
      sendMessage();
    }
  });

  async function sendMessage() {
    const msg = input.value.trim();
    if (!msg) return;

    chatWindow.innerHTML += `<div class="user-msg">${msg}</div>`;
    input.value = "";

    try {
      const res = await fetch("/chatbot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: msg })
      });

      const data = await res.json();
      chatWindow.innerHTML += `<div class="bot-msg">${data.reply}</div>`;
    } catch {
      chatWindow.innerHTML += `<div class="bot-msg">Server not responding 😓</div>`;
    }

    chatWindow.scrollTop = chatWindow.scrollHeight;
  }

});



//login 
function toggleLamp() {
    const lamp = document.getElementById("lampWrapper");
    const login = document.getElementById("login-box");

    lamp.classList.toggle("active");
    login.classList.toggle("show");
}

function showSignup() {
  document.getElementById('login-box').classList.remove('show');
  document.getElementById('signup-box').classList.add('show');
}

function showLogin() {
  document.getElementById('signup-box').classList.remove('show');
  document.getElementById('login-box').classList.add('show');
}

function signup() {
  const username = document.getElementById('signup-username').value;
  const password = document.getElementById('signup-password').value;

  if (username && password) {
    localStorage.setItem(username, password);
    alert("Account created! Please login.");
    showLogin();
  } else {
    alert("Please fill all fields.");
  }
}

function login() {
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;

  const storedPassword = localStorage.getItem(username);

  if (storedPassword && storedPassword === password) {
    alert("Login successful! Redirecting to index page...");
    window.location.href = "index.html"; // Redirect to your index.html
  } else {
    alert("Account not found or wrong password. Please sign up.");
    showSignup();
  }
}