from flask import Flask, jsonify, render_template, request,redirect,url_for,session
from flask_cors import CORS
import mysql.connector
import os
from openai import OpenAI
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from werkzeug.security import generate_password_hash, check_password_hash
from flask import session





app = Flask(__name__)
CORS(app)

app.secret_key = "college_nav_secret_123"
# ---------------- DATABASE ----------------

try:
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="RS12@shrey",
        database="college_nav"
    )
except mysql.connector.Error as err:
    print("DB Error:", err)
    db = None


# ---------------- OPENAI SETUP ----------------
# Hardcode your API key here (Option 2)
client = OpenAI(api_key="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")


# ---------------- FAQ FUNCTIONS ----------------
def load_faq():
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT question, answer FROM faq")
    faq_data = {row["question"].lower(): row["answer"] for row in cursor.fetchall()}
    cursor.close()
    return faq_data

faq_data = load_faq()
faq_questions = list(faq_data.keys())
faq_answers = list(faq_data.values())

def faq_response(user_query):
    vectorizer = TfidfVectorizer()
    vectors = vectorizer.fit_transform(faq_questions + [user_query])
    similarity_scores = cosine_similarity(vectors[-1], vectors[:-1])
    idx = similarity_scores.argmax()
    if similarity_scores[0][idx] > 0.3:  # threshold
        return faq_answers[idx]
    return None

def gpt_response(user_query):
    response = client.chat.completions.create(

        model="gpt-3.5-turbo",  # or gpt-4
        messages=[{"role": "user", "content": user_query}]
    )
    return response.choices[0].message["content"]



# ---------------- CAMPUS KEYWORDS ----------------

CAMPUS_KEYWORDS = [
    "college", "campus", "library", "office", "canteen", "hostel",
    "lab", "department", "classroom", "fees", "exam",
    "principal", "admission", "timing", "bus",
    "parking", "wifi", "sports", "ground",
    "map", "location", "where", "how to reach",
    "admin", "attendance", "syllabus"
]


def is_campus_related(question):

    q = question.lower()

    return any(word in q for word in CAMPUS_KEYWORDS)

def clean_place(text):

    remove_words = [
        "where is", "where", "located", "location of",
        "show me", "tell me", "please", "?", "."
    ]

    text = text.lower()

    for word in remove_words:
        text = text.replace(word, "")

    return text.strip()



# ---------------- ROUTES ----------------


@app.route("/")
def home():
    if "username" in session:
        return render_template("index.html", username=session["username"])
    return redirect(url_for("login"))

#--------------------------------------------------------------#


def find_location(place):

    cursor = db.cursor(dictionary=True)

    query = """
    SELECT location, latitude, longitude
    FROM locations
    WHERE LOWER(location) LIKE %s
    LIMIT 1
    """

    cursor.execute(query, ("%" + place.lower() + "%",))

    result = cursor.fetchone()

    cursor.close()

    return result


def extract_place(question):

    words = question.lower().split()

    ignore = ["where", "is", "the", "a", "an", "of", "please"]

    place = [w for w in words if w not in ignore]

    return " ".join(place)


# ---------- Location API ----------

@app.route("/locations", methods=["GET"])
def get_locations():

    if db is None:
        return jsonify({"error": "Database not connected"}), 500

    db.reconnect(attempts=1, delay=0)

    cursor = db.cursor(dictionary=True)

    cursor.execute("""
        SELECT id, location,
        ROUND(latitude,5) AS latitude,
        ROUND(longitude,5) AS longitude
        FROM locations
    """)

    data = cursor.fetchall()

    cursor.close()

    return jsonify(data)


# ---------- Chatbot API ----------

@app.route("/chatbot", methods=["POST"])
def chatbot():
    data = request.get_json()
    user_message = data.get("message")

    if not user_message:
        return jsonify({"reply": "Please type something."})

    # 1. Check FAQ
    faq_answer = faq_response(user_message)
    if faq_answer:
        return jsonify({"reply": faq_answer})

    # 2. Check Location
    if "where is" in user_message.lower():
        place = extract_place(user_message)
        location = find_location(place)
        if location:
            lat, lon, name = location["latitude"], location["longitude"], location["location"]
            map_link = f"https://www.google.com/maps?q={lat},{lon}"
            reply = f"""📍 <b>{name}</b><br><a href="{map_link}" target="_blank">👉 Open in Google Maps</a>"""
            return jsonify({"reply": reply})
        else:
            return jsonify({"reply": "Sorry, this location is not in database."})

    # 3. Fallback to GPT
    try:
        reply = gpt_response(user_message)
    except Exception as e:
        reply = "AI Error: " + str(e)

    return jsonify({"reply": reply})


#login ,signup page


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE username=%s", (username,))
        user = cursor.fetchone()
        cursor.close()

        if user and check_password_hash(user["password"], password):
            session["username"] = username
            return redirect(url_for("home"))
        else:
            return "Invalid credentials. Please sign up."

    return render_template("login.html")




@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE username=%s", (username,))
        existing_user = cursor.fetchone()

        if existing_user:
            cursor.close()
            return "Account already exists. Please login."

        hashed_pw = generate_password_hash(password)
        cursor.execute(
            "INSERT INTO users (username, password) VALUES (%s, %s)",
            (username, hashed_pw)
        )
        db.commit()
        cursor.close()

        return redirect(url_for("login"))

    return render_template("signup.html")

@app.route("/logout")
def logout():
    session.pop("username", None)
    return redirect(url_for("login"))









# ---------------- RUN ----------------

if __name__ == "__main__":
    app.run(debug=True)
